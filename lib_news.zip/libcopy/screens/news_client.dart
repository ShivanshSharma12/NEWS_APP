import 'package:dio/dio.dart';

class NewsClient{
  Dio _dio= Dio();

  getNewsDataFromAPI() async{
    String newsURL = 'https://newsapi.org/v2/top-headlines?country=us&apiKey=2fc9abe6ae1b4522bad592c449db81ae';
    try{
      var response = await _dio.get(newsURL);
      print("this is the next data from api ${response.data}");
      return response.data;
    }  catch(error) {
      print("something went wrong");
    }
  }
}